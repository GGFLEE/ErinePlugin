# 百度文心一言web插件



## 使用:

兔兔文心+用户内容(*~~可以画图~~*)

仅支持对话

谨慎使用,有封号风险~~(不是)~~

##  配置

1. 访问[文心一言](https://yiyan.baidu.com/).
2. 打开开发者工具.
3. 找到应用程序(Application).
4. 在左侧点击存储(Storage)-Cookies-[https://yiyan.baidu.com](https://yiyan.baidu.com/).
5. 在列表中点击BAIDUID.
6. 复制下方Cookie Value的值.
7. BDUSS_BFESS同理.
8. 控制台填写配置

![图片1](https://camo.githubusercontent.com/9143d4930a1e070829df5752206803b24d0a7011274a11f3f2285ff783843c99/68747470733a2f2f73312e617831782e636f6d2f323032332f30342f32362f70394b445559522e6d642e706e67)

#### 来自

[XiaoXinYo/Easy-Ernie: 文心一言API. (github.com)](https://github.com/XiaoXinYo/Easy-Ernie)



## 仓库地址

[GGFLEE/ErniePlugin: Amiyabot文心一言web插件 (github.com)](https://github.com/GGFLEE/ErniePlugin)







